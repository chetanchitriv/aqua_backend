module.exports = {
    secret: "shank-secret-key"
  };